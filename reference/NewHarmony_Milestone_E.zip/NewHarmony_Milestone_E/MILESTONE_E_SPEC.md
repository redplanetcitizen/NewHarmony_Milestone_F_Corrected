# Milestone E specification

Milestone E is the final validation and freeze of the 2019–2023 empirical New Harmony engine. It does not introduce a new historical calibration target and it does not force the planner to reproduce observed U.S. gross fixed investment.

## M10 — investment-gap diagnosis and horizon boundary

1. Replay Milestone D exactly.
2. Quantify the difference between planner investment and observed BEA real investment.
3. Compare that gap with observed depreciation and with the observed fixed-asset stock path.
4. Decompose the observed fixed-asset flows by **private/government ownership** and by **equipment, structures, and intellectual-property products (IPP)** using the underlying BEA Fixed Assets tables. The decomposition is diagnostic only; BEA chain-type component volumes are reconciled explicitly to the accepted 71-sector real totals because they are not strictly additive away from the reference year.
5. Preserve the 71-sector gap ranking, including the Housing sector, so the residential contribution remains directly visible without adding Section 5 residential totals a second time.
6. Test whether the last-year zero-investment result is mainly a finite-horizon artifact by appending one stationary shadow continuation year.
7. Adopt the stationary shadow continuation year as the default boundary treatment for future prospective applications. It is a boundary condition, not an observed historical year, and it does not rewrite the accepted 2019–2023 benchmark.

## M11 — robustness and final freeze

Run one-at-a-time perturbations around the accepted D model: initial capital ±10%, depreciation ±10%, FTE availability ±5%, social targets ±5%, and import envelope ±10%, in both Frozen and Historical technology modes. The investment-gap conclusion must survive these perturbations without non-finite solutions or non-positive accepted capital transfers.

A separate maintenance-floor diagnostic forces 0%, 10%, 20%, and 30% of modeled depreciation to be replaced before Harmony-directed additions. This is a sensitivity experiment only; it is not the accepted planner rule.

## Acceptance interpretation

Milestone E passes if the low investment ratio is shown to be robust and economically interpretable as a consequence of New Harmony's marginal capacity-relief rule, rather than a numerical instability or a hidden calibration error. Milestone E is the final required construction milestone; subsequent 2024/2025–2029 work is an application of the frozen engine.
