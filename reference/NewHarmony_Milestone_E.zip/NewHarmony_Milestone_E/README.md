# New Harmony — Milestone E (ACCEPTED)

Milestone E is the **final required construction milestone** for the empirical 71-sector U.S. New Harmony backtest. Milestone D is preserved exactly as the predecessor; E adds final investment-gap diagnosis, fixed-asset composition analysis, robustness testing, and the terminal-horizon rule needed before prospective use.

## Frozen historical baseline

The accepted five-year benchmark remains 2019–2023. E does not fit the solver to historical investment and does not replace the New Harmony objective with an LP or an error-minimization criterion.

| Mode | Final mean Harmony | Final CV | Capital transfers | Planner / observed investment | 2023 model / observed stock |
|---|---:|---:|---:|---:|---:|
| Frozen | 0.429414054 | 0.072213654 | 111 | 6.552% | 72.790% |
| Historical | 0.417848385 | 0.091994000 | 142 | 6.311% | 72.686% |

Milestone D's M09 inventory module accepted zero real-data transfers under its conservative F030 envelope, so the E investment diagnostics use the numerically identical M08 capital path. The exact D archive is nevertheless replayed in acceptance testing, including all 25 D tests.

## What E establishes

Observed real investment is 23.623 trillion 2019-price dollars over 2019–2023, versus about 1.49–1.55 trillion chosen by New Harmony. Observed depreciation is 18.510 trillion: 78.35% of observed investment and roughly 84% of the scale of the observed-minus-planned gap. The planner allows non-binding capital to run down, ending 2023 at about 72.7–72.8% of the observed fixed-asset stock.

The underlying BEA fixed-asset tables show that the observed investment flow is not concentrated in one asset class. On the component 2019-price decomposition, about 38.6% is structures, 32.6% intellectual-property products, and 28.8% equipment; about 83.0% is private and 17.0% government. Because BEA chain-type component volumes are not strictly additive away from the reference year, the package reports their reconciliation to the accepted 71-sector real series explicitly; the maximum annual absolute discrepancy is about 0.176%.

This result is robust. Across the accepted one-at-a-time sensitivity grid, planner investment remains 5.62–7.91% of observed investment. A stationary shadow continuation year makes 2023 investment positive, but the five-year ratio still remains below 8%; finite-horizon liquidation is therefore real but not the main explanation.

The conclusion is that New Harmony's investment variable should be interpreted as **marginal capacity-relief investment required by the plan**, not as a forecast of gross fixed capital formation. Broad replacement floors can raise stock and investment, but reduce mean Harmony relative to the targeted baseline and are therefore retained only as diagnostics.

## Prospective boundary rule

For future plans, the last reported year receives one stationary shadow continuation year unless an explicit next-year target is provided. The shadow year repeats the final target, technology, labour availability, and import envelope. It exists only to give last-year investment a continuation value; it is not reported as an observed year.

## Main files

- `code/new_harmony_empirical_e.py` — M10/M11 validation and terminal-continuation layer.
- `data/fixed_asset_composition_2019_2023.csv` — BEA private/government × equipment/structures/IPP diagnostic input.
- `data/FIXED_ASSET_COMPOSITION_AUDIT.json` — source and chain-index construction audit.
- `results/investment_gap/INVESTMENT_GAP_HEADLINE.csv` — aggregate gap accounting.
- `results/investment_gap/INVESTMENT_GAP_ANNUAL.csv` — annual decomposition.
- `results/investment_gap/INVESTMENT_GAP_BY_SECTOR.csv` — 71-sector cumulative comparison.
- `results/investment_gap/ASSET_COMPOSITION_HEADLINE.csv` — fixed-asset flow composition by owner and asset class.
- `results/investment_gap/ASSET_COMPOSITION_RECONCILIATION.csv` — component-volume reconciliation to the accepted 71-sector real series.
- `results/robustness/SENSITIVITY_RESULTS.csv` — 22 robustness runs.
- `results/robustness/TERMINAL_HORIZON_DIAGNOSTIC.csv` — finite-horizon test.
- `results/robustness/MAINTENANCE_FLOOR_DIAGNOSTIC.csv` — broad replacement sensitivity.
- `FINAL_MODEL_INTERPRETATION.md` — final methodological conclusion.
- `tests/test_milestone_e.py` — 24-test acceptance suite.
- `reference/NewHarmony_Milestone_D.zip` — exact locked predecessor.

After Milestone E, the 2019–2023 engine is frozen. A 2024/2025–2029 exercise is a prospective application of this engine, not a Milestone F required for construction.
