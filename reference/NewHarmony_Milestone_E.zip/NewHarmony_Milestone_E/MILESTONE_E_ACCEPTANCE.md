# Milestone E acceptance

**Status: ACCEPTED**

Milestone E closes the required construction sequence A–E.

## Acceptance gates

- Exact Milestone D predecessor SHA verified.
- Exact predecessor archive replays **25/25 tests**.
- E acceptance suite passes **24/24 tests**.
- Frozen and Historical baseline values reproduce accepted D to numerical tolerance.
- The 2019–2023, 71-sector contract is unchanged.
- No historical-investment fitting or calibration is introduced.
- All baseline accepted capital transfers remain forward in time and positive in mean-Harmony gain.
- The investment gap is quantified using the existing accepted BEA real fixed-asset accounts.
- BEA fixed-asset flows are additionally decomposed by private/government ownership and equipment/structures/IPP.
- Component 2019-price volumes reconcile to the accepted 71-sector real flow series with a maximum annual absolute residual below 0.2%, explicitly acknowledging chain-index nonadditivity.
- The gap persists across all 22 one-at-a-time robustness runs.
- A stationary shadow continuation year restores positive terminal-year investment but leaves the investment ratio below 8%, demonstrating that finite-horizon liquidation is secondary.
- Broad depreciation-maintenance floors raise investment and terminal stock but lower optimized mean Harmony relative to the targeted baseline; they remain diagnostics, not policy constraints.

## Final empirical conclusion

Frozen planner investment is 1.548 trillion versus 23.623 trillion observed (6.55%). Historical planner investment is 1.491 trillion (6.31%). Observed depreciation totals 18.510 trillion and is of the same dominant scale as the gap. The planner ends 2023 with roughly 72.7–72.8% of observed fixed-asset stock because capital that is not required to relieve binding plan constraints is allowed to depreciate.

The BEA asset-composition diagnostic confirms that the historical flow is broad: component real investment is approximately 38.6% structures, 32.6% IPP and 28.8% equipment; 83.0% private and 17.0% government. The low planner total therefore cannot be attributed to omitting just one conventional asset class or only public investment.

This is accepted as a robust structural property of the New Harmony investment rule, not hidden by calibration. The engine is therefore frozen as a **normative marginal-capacity planner**, not as a historical GFCF predictor.

## Boundary rule for prospective plans

A future multi-year plan must append one stationary continuation year, or supply an explicit next-year target, so that investment in the final reported year has productive continuation value. This rule is implemented in `solve_with_terminal_continuation()` and does not alter the locked historical benchmark.

There is no required Milestone F. The next stage is application of the frozen engine to the contemporary planning horizon.
